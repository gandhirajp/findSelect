export const metadata = {
  title: 'About',
  description: 'This is about page.',
};

export default function AboutPage() {
  return <h1 className="mt-12 text-center text-3xl font-bold">About</h1>;
}
