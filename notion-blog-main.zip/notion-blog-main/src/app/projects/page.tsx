export const metadata = {
  title: 'Projects',
  description: 'This is projects page.',
};

export default function ProjectsPage() {
  return <h1 className="mt-12 text-center text-3xl font-bold">Projects</h1>;
}
