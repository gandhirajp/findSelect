export const metadata = {
  title: 'Welcome | Jihoo Kim',
};

export default function HomePage() {
  return <h1 className="mt-12 text-center text-3xl font-bold">Home</h1>;
}
