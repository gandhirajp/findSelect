export const metadata = {
  title: 'Contact',
  description: 'This is contact page.',
};

export default function ContactPage() {
  return <h1 className="mt-12 text-center text-3xl font-bold">Contact</h1>;
}
